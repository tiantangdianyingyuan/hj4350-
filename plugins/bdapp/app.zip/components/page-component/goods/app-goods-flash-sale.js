(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/goods/app-goods-flash-sale"],{"778a":function(t,n,a){},7807:function(t,n,a){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={name:"app-goods-flash-sale",props:{flash_sale:{type:Object,default:function(){return{time_status:1,start_at:"",end_at:"",min_discount:""}}},theme:String},methods:{navigator:function(){t.navigateTo({url:this.flash_sale.url})}}};n.default=a}).call(this,a("5486")["default"])},a8a3:function(t,n,a){"use strict";var e=a("778a"),u=a.n(e);u.a},c20d:function(t,n,a){"use strict";a.r(n);var e=a("7807"),u=a.n(e);for(var o in e)"default"!==o&&function(t){a.d(n,t,function(){return e[t]})}(o);n["default"]=u.a},c2b7:function(t,n,a){"use strict";a.r(n);var e=a("cf70"),u=a("c20d");for(var o in u)"default"!==o&&function(t){a.d(n,t,function(){return u[t]})}(o);a("a8a3");var r=a("2877"),c=Object(r["a"])(u["default"],e["a"],e["b"],!1,null,"25bd7839",null);n["default"]=c.exports},cf70:function(t,n,a){"use strict";var e=function(){var t=this,n=t.$createElement;t._self._c},u=[];a.d(n,"a",function(){return e}),a.d(n,"b",function(){return u})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/goods/app-goods-flash-sale-create-component',
    {
        'components/page-component/goods/app-goods-flash-sale-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("c2b7"))
        })
    },
    [['components/page-component/goods/app-goods-flash-sale-create-component']]
]);                
