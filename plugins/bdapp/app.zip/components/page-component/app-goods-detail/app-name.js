(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-goods-detail/app-name"],{"0cd0":function(n,t,e){},1691:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var a={name:"name",props:{name:String}};t.default=a},"1caa":function(n,t,e){"use strict";e.r(t);var a=e("adf2"),u=e("b8eb");for(var r in u)"default"!==r&&function(n){e.d(t,n,function(){return u[n]})}(r);e("9a78");var o=e("2877"),c=Object(o["a"])(u["default"],a["a"],a["b"],!1,null,"67848114",null);t["default"]=c.exports},"9a78":function(n,t,e){"use strict";var a=e("0cd0"),u=e.n(a);u.a},adf2:function(n,t,e){"use strict";var a=function(){var n=this,t=n.$createElement;n._self._c},u=[];e.d(t,"a",function(){return a}),e.d(t,"b",function(){return u})},b8eb:function(n,t,e){"use strict";e.r(t);var a=e("1691"),u=e.n(a);for(var r in a)"default"!==r&&function(n){e.d(t,n,function(){return a[n]})}(r);t["default"]=u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-goods-detail/app-name-create-component',
    {
        'components/page-component/app-goods-detail/app-name-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("1caa"))
        })
    },
    [['components/page-component/app-goods-detail/app-name-create-component']]
]);                
