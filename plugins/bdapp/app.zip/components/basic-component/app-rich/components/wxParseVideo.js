(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/basic-component/app-rich/components/wxParseVideo"],{"1e21":function(n,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var a={name:"wxParseVideo",props:{node:{}}};e.default=a},"26a1":function(n,e,t){"use strict";t.r(e);var a=t("1e21"),r=t.n(a);for(var u in a)"default"!==u&&function(n){t.d(e,n,function(){return a[n]})}(u);e["default"]=r.a},"9b8f":function(n,e,t){"use strict";var a=function(){var n=this,e=n.$createElement;n._self._c},r=[];t.d(e,"a",function(){return a}),t.d(e,"b",function(){return r})},b9a8:function(n,e,t){"use strict";t.r(e);var a=t("9b8f"),r=t("26a1");for(var u in r)"default"!==u&&function(n){t.d(e,n,function(){return r[n]})}(u);var o=t("2877"),c=Object(o["a"])(r["default"],a["a"],a["b"],!1,null,null,null);e["default"]=c.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/basic-component/app-rich/components/wxParseVideo-create-component',
    {
        'components/basic-component/app-rich/components/wxParseVideo-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('5486')['createComponent'](__webpack_require__("b9a8"))
        })
    },
    [['components/basic-component/app-rich/components/wxParseVideo-create-component']]
]);                
