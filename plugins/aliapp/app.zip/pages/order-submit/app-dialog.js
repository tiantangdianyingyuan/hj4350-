;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["pages/order-submit/app-dialog"],{"443f":function(t,i,e){"use strict";e.r(i);var n=e("dda1"),a=e("c492");for(var u in a)"default"!==u&&function(t){e.d(i,t,function(){return a[t]})}(u);e("aa71");var s=e("2877"),c=Object(s["a"])(a["default"],n["a"],n["b"],!1,null,"7dcec769",null);i["default"]=c.exports},a060b:function(t,i,e){},aa71:function(t,i,e){"use strict";var n=e("a060b"),a=e.n(n);a.a},c492:function(t,i,e){"use strict";e.r(i);var n=e("d8ef"),a=e.n(n);for(var u in n)"default"!==u&&function(t){e.d(i,t,function(){return n[t]})}(u);i["default"]=a.a},d8ef:function(t,i,e){"use strict";Object.defineProperty(i,"__esModule",{value:!0}),i.default=void 0;var n={name:"app-dialog",props:{title:{default:""},content:{default:""},visible:{type:Boolean,default:!1},confirmText:{default:"确认"}},data:function(){return{iVisible:this.visible}},watch:{visible:function(t){this.iVisible=t}},methods:{close:function(){this.iVisible=!1,this.$emit("update:visible",this.iVisible)},confirm:function(){this.iVisible=!1,this.$emit("update:visible",this.iVisible)}}};i.default=n},dda1:function(t,i,e){"use strict";var n=function(){var t=this,i=t.$createElement;t._self._c},a=[];e.d(i,"a",function(){return n}),e.d(i,"b",function(){return a})}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'pages/order-submit/app-dialog-create-component',
    {
        'pages/order-submit/app-dialog-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("443f"))
        })
    },
    [['pages/order-submit/app-dialog-create-component']]
]);                
