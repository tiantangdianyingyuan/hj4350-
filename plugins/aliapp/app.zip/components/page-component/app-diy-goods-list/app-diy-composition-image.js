;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-diy-goods-list/app-diy-composition-image"],{"715b":function(t,e,n){},"92f0":function(t,e,n){"use strict";n.r(e);var o=n("ad45"),a=n("a297");for(var r in a)"default"!==r&&function(t){n.d(e,t,function(){return a[t]})}(r);n("f7e1");var i=n("2877"),u=Object(i["a"])(a["default"],o["a"],o["b"],!1,null,"35b064d2",null);e["default"]=u.exports},a297:function(t,e,n){"use strict";n.r(e);var o=n("ad3b"),a=n.n(o);for(var r in o)"default"!==r&&function(t){n.d(e,t,function(){return o[t]})}(r);e["default"]=a.a},ad3b:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var o={name:"app-diy-composition-image",props:{imageList:Array,mode:String},computed:{imageClass:function(){var t=this.imageList.length;switch(t){case 1:return"goods-one";case 2:return"goods-two";case 3:return"goods-three";case 4:return"goods-four";case 5:return"goods-five"}}}};e.default=o},ad45:function(t,e,n){"use strict";var o=function(){var t=this,e=t.$createElement;t._self._c},a=[];n.d(e,"a",function(){return o}),n.d(e,"b",function(){return a})},f7e1:function(t,e,n){"use strict";var o=n("715b"),a=n.n(o);a.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-diy-goods-list/app-diy-composition-image-create-component',
    {
        'components/page-component/app-diy-goods-list/app-diy-composition-image-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("92f0"))
        })
    },
    [['components/page-component/app-diy-goods-list/app-diy-composition-image-create-component']]
]);                
