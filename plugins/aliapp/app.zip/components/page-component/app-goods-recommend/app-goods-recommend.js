;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-goods-recommend/app-goods-recommend"],{"76be":function(n,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var o=function(){return t.e("components/page-component/u-goods-list/u-ordinary-list").then(t.bind(null,"24ba"))},r={name:"app-goods-recommend",components:{uOrdinaryList:o},props:{goodsList:Array,theme:String,sureCart:Boolean,activity:Object,is_show_member:{type:Boolean,default:function(){return!0}},sign:String,detail:Object}};e.default=r},"80e1":function(n,e,t){"use strict";t.r(e);var o=t("76be"),r=t.n(o);for(var u in o)"default"!==u&&function(n){t.d(e,n,function(){return o[n]})}(u);e["default"]=r.a},"88b0":function(n,e,t){"use strict";var o=t("f08e"),r=t.n(o);r.a},"8e97":function(n,e,t){"use strict";t.r(e);var o=t("d373"),r=t("80e1");for(var u in r)"default"!==u&&function(n){t.d(e,n,function(){return r[n]})}(u);t("88b0");var a=t("2877"),i=Object(a["a"])(r["default"],o["a"],o["b"],!1,null,"0c455baa",null);e["default"]=i.exports},d373:function(n,e,t){"use strict";var o=function(){var n=this,e=n.$createElement;n._self._c},r=[];t.d(e,"a",function(){return o}),t.d(e,"b",function(){return r})},f08e:function(n,e,t){}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-goods-recommend/app-goods-recommend-create-component',
    {
        'components/page-component/app-goods-recommend/app-goods-recommend-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("8e97"))
        })
    },
    [['components/page-component/app-goods-recommend/app-goods-recommend-create-component']]
]);                
