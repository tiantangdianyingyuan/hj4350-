;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-pt-attr/app-pt-attr"],{"051f":function(t,e,n){"use strict";n.r(e);var r=n("5e8d"),a=n("5dbd");for(var u in a)"default"!==u&&function(t){n.d(e,t,function(){return a[t]})}(u);n("91ab");var c=n("2877"),o=Object(c["a"])(a["default"],r["a"],r["b"],!1,null,"a2f6436e",null);e["default"]=o.exports},"5dbd":function(t,e,n){"use strict";n.r(e);var r=n("e9a6"),a=n.n(r);for(var u in r)"default"!==u&&function(t){n.d(e,t,function(){return r[t]})}(u);e["default"]=a.a},"5e8d":function(t,e,n){"use strict";var r=function(){var t=this,e=t.$createElement;t._self._c},a=[];n.d(e,"a",function(){return r}),n.d(e,"b",function(){return a})},"7a1a":function(t,e,n){},"91ab":function(t,e,n){"use strict";var r=n("7a1a"),a=n.n(r);a.a},e9a6:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={name:"app-pt-attr",props:{groups:{type:Array,default:function(){return[]}},selectGroupAttrId:String,theme:String},methods:{active:function(t){this.$emit("click",t)}},computed:{select:function(){return this.selectGroupAttrId}}};e.default=r}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-pt-attr/app-pt-attr-create-component',
    {
        'components/page-component/app-pt-attr/app-pt-attr-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("051f"))
        })
    },
    [['components/page-component/app-pt-attr/app-pt-attr-create-component']]
]);                
