;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/page-component/app-order-banner/app-order-banner"],{4474:function(e,t,n){"use strict";n.r(t);var r=n("a61e"),a=n.n(r);for(var u in r)"default"!==u&&function(e){n.d(t,e,function(){return r[e]})}(u);t["default"]=a.a},"4d0d":function(e,t,n){"use strict";var r=function(){var e=this,t=e.$createElement;e._self._c},a=[];n.d(t,"a",function(){return r}),n.d(t,"b",function(){return a})},"96db":function(e,t,n){"use strict";var r=n("eee3c"),a=n.n(r);a.a},a61e:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r={name:"app-order-banner",data:function(){return{newPicUrl:""}},props:{title:{type:String,value:""},picUrl:{type:String,value:""},hint:{type:String,value:""}},created:function(){this.newPicUrl=this.$store.state.mallConfig.__wxapp_img.mall.order.status_bar}};t.default=r},ccb8:function(e,t,n){"use strict";n.r(t);var r=n("4d0d"),a=n("4474");for(var u in a)"default"!==u&&function(e){n.d(t,e,function(){return a[e]})}(u);n("96db");var i=n("2877"),c=Object(i["a"])(a["default"],r["a"],r["b"],!1,null,"9440bd70",null);t["default"]=c.exports},eee3c:function(e,t,n){}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/page-component/app-order-banner/app-order-banner-create-component',
    {
        'components/page-component/app-order-banner/app-order-banner-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("ccb8"))
        })
    },
    [['components/page-component/app-order-banner/app-order-banner-create-component']]
]);                
