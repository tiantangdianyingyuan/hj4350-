;my.defineComponent || (my.defineComponent = Component);(my["webpackJsonp"]=my["webpackJsonp"]||[]).push([["components/basic-component/app-loading/app-loading"],{"140e":function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={name:"app-loading",props:{type:{type:String,default:function(){return""}},text:{type:String,default:function(){return""}},color:{type:String,default:function(){return""}},backgroundImage:{type:String,default:function(){return""}}},computed:{background:function(){return this.backgroundImage}}};t.default=u},2428:function(n,t,e){"use strict";e.r(t);var u=e("982f"),r=e("f87c");for(var a in r)"default"!==a&&function(n){e.d(t,n,function(){return r[n]})}(a);e("58b2");var c=e("2877"),o=Object(c["a"])(r["default"],u["a"],u["b"],!1,null,"3d988c75",null);t["default"]=o.exports},"58b2":function(n,t,e){"use strict";var u=e("9146"),r=e.n(u);r.a},9146:function(n,t,e){},"982f":function(n,t,e){"use strict";var u=function(){var n=this,t=n.$createElement;n._self._c},r=[];e.d(t,"a",function(){return u}),e.d(t,"b",function(){return r})},f87c:function(n,t,e){"use strict";e.r(t);var u=e("140e"),r=e.n(u);for(var a in u)"default"!==a&&function(n){e.d(t,n,function(){return u[n]})}(a);t["default"]=r.a}}]);
;(my["webpackJsonp"] = my["webpackJsonp"] || []).push([
    'components/basic-component/app-loading/app-loading-create-component',
    {
        'components/basic-component/app-loading/app-loading-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('c11b')['createComponent'](__webpack_require__("2428"))
        })
    },
    [['components/basic-component/app-loading/app-loading-create-component']]
]);                
