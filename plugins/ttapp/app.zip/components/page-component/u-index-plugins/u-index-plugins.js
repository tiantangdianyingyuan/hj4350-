(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/u-index-plugins/u-index-plugins"],{"03c5":function(n,t,u){"use strict";u.r(t);var e=u("7af9"),r=u("505b");for(var a in r)"default"!==a&&function(n){u.d(t,n,function(){return r[n]})}(a);u("4125");var i=u("2877"),f=Object(i["a"])(r["default"],e["a"],e["b"],!1,null,"67c8dd5e",null);t["default"]=f.exports},"137f":function(n,t,u){},4125:function(n,t,u){"use strict";var e=u("137f"),r=u.n(e);r.a},"505b":function(n,t,u){"use strict";u.r(t);var e=u("df27"),r=u.n(e);for(var a in e)"default"!==a&&function(n){u.d(t,n,function(){return e[n]})}(a);t["default"]=r.a},"7af9":function(n,t,u){"use strict";var e=function(){var n=this,t=n.$createElement;n._self._c},r=[];u.d(t,"a",function(){return e}),u.d(t,"b",function(){return r})},df27:function(n,t,u){"use strict";(function(n){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={name:"u-index-plugins",props:{list:{type:Array},url:{type:String}},methods:{router:function(){n.navigateTo({url:this.url})}}};t.default=u}).call(this,u("f266")["default"])}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/u-index-plugins/u-index-plugins-create-component',
    {
        'components/page-component/u-index-plugins/u-index-plugins-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("03c5"))
        })
    },
    [['components/page-component/u-index-plugins/u-index-plugins-create-component']]
]);                
