(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-goods-detail/app-name"],{"0cd0":function(n,e,t){},1691:function(n,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var a={name:"name",props:{name:String}};e.default=a},"1caa":function(n,e,t){"use strict";t.r(e);var a=t("eea9"),u=t("b8eb");for(var r in u)"default"!==r&&function(n){t.d(e,n,function(){return u[n]})}(r);t("9a78");var o=t("2877"),c=Object(o["a"])(u["default"],a["a"],a["b"],!1,null,"67848114",null);e["default"]=c.exports},"9a78":function(n,e,t){"use strict";var a=t("0cd0"),u=t.n(a);u.a},b8eb:function(n,e,t){"use strict";t.r(e);var a=t("1691"),u=t.n(a);for(var r in a)"default"!==r&&function(n){t.d(e,n,function(){return a[n]})}(r);e["default"]=u.a},eea9:function(n,e,t){"use strict";var a=function(){var n=this,e=n.$createElement;n._self._c},u=[];t.d(e,"a",function(){return a}),t.d(e,"b",function(){return u})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-goods-detail/app-name-create-component',
    {
        'components/page-component/app-goods-detail/app-name-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("1caa"))
        })
    },
    [['components/page-component/app-goods-detail/app-name-create-component']]
]);                
