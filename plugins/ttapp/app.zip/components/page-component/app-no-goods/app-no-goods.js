(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/page-component/app-no-goods/app-no-goods"],{3640:function(n,t,e){"use strict";var u=function(){var n=this,t=n.$createElement;n._self._c},r=[];e.d(t,"a",function(){return u}),e.d(t,"b",function(){return r})},"3da24":function(n,t,e){"use strict";e.r(t);var u=e("4742"),r=e.n(u);for(var o in u)"default"!==o&&function(n){e.d(t,n,function(){return u[n]})}(o);t["default"]=r.a},4742:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={name:"app-no-goods",props:{background:{type:String,default:function(){return"#ffffff"}},color:{type:String,default:function(){return"#666666"}},title:{type:String,default:function(){return"没有任何商品哦~"}},is_image:{type:Number,default:function(){return 0}}}};t.default=u},8112:function(n,t,e){"use strict";e.r(t);var u=e("3640"),r=e("3da24");for(var o in r)"default"!==o&&function(n){e.d(t,n,function(){return r[n]})}(o);e("f1639");var f=e("2877"),a=Object(f["a"])(r["default"],u["a"],u["b"],!1,null,"7d5dcfc3",null);t["default"]=a.exports},d24d:function(n,t,e){},f1639:function(n,t,e){"use strict";var u=e("d24d"),r=e.n(u);r.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/page-component/app-no-goods/app-no-goods-create-component',
    {
        'components/page-component/app-no-goods/app-no-goods-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("8112"))
        })
    },
    [['components/page-component/app-no-goods/app-no-goods-create-component']]
]);                
