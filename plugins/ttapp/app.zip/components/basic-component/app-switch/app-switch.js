(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/basic-component/app-switch/app-switch"],{"10a9":function(t,n,e){"use strict";e.r(n);var a=e("4ca9"),i=e.n(a);for(var c in a)"default"!==c&&function(t){e.d(n,t,function(){return a[t]})}(c);n["default"]=i.a},"4ca9":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={name:"app-switch",data:function(){return{x:0,switch:this.value}},props:{theme:String,value:{default:!1}},methods:{switchChange:function(){this.switch=!this.switch,this.$emit("input",this.switch)}},computed:{themeColor:function(){return 88===this.x?"".concat(this.theme,"-background"):""}},watch:{value:{handler:function(t){!1===t?this.x=0:!0===t&&(this.x=88)},immediate:!0}}};n.default=a},"61ac":function(t,n,e){"use strict";e.r(n);var a=e("c4ae"),i=e("10a9");for(var c in i)"default"!==c&&function(t){e.d(n,t,function(){return i[t]})}(c);e("a3a5");var u=e("2877"),r=Object(u["a"])(i["default"],a["a"],a["b"],!1,null,null,null);n["default"]=r.exports},75390:function(t,n,e){},a3a5:function(t,n,e){"use strict";var a=e("75390"),i=e.n(a);i.a},c4ae:function(t,n,e){"use strict";var a=function(){var t=this,n=t.$createElement;t._self._c},i=[];e.d(n,"a",function(){return a}),e.d(n,"b",function(){return i})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/basic-component/app-switch/app-switch-create-component',
    {
        'components/basic-component/app-switch/app-switch-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("61ac"))
        })
    },
    [['components/basic-component/app-switch/app-switch-create-component']]
]);                
