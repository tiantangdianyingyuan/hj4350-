(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/basic-component/app-layout/app-permissions-auth/app-permissions-auth"],{"1c4d":function(t,n,e){"use strict";e.r(n);var a=e("e57b"),u=e("8111");for(var o in u)"default"!==o&&function(t){e.d(n,t,function(){return u[t]})}(o);e("743d");var r=e("2877"),c=Object(r["a"])(u["default"],a["a"],a["b"],!1,null,"6602b2aa",null);n["default"]=c.exports},"743d":function(t,n,e){"use strict";var a=e("c41a"),u=e.n(a);u.a},8111:function(t,n,e){"use strict";e.r(n);var a=e("b0f0"),u=e.n(a);for(var o in a)"default"!==o&&function(t){e.d(n,t,function(){return a[t]})}(o);n["default"]=u.a},b0f0:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={name:"app-permissions-auth",data:function(){return{}},props:{isShow:{type:Boolean,default:!1},text:{type:String,default:"请在设置中打开相应权限"}},methods:{cancel:function(){this.$emit("cancel",!1)}}};n.default=a},c41a:function(t,n,e){},e57b:function(t,n,e){"use strict";var a=function(){var t=this,n=t.$createElement;t._self._c},u=[];e.d(n,"a",function(){return a}),e.d(n,"b",function(){return u})}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/basic-component/app-layout/app-permissions-auth/app-permissions-auth-create-component',
    {
        'components/basic-component/app-layout/app-permissions-auth/app-permissions-auth-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('f266')['createComponent'](__webpack_require__("1c4d"))
        })
    },
    [['components/basic-component/app-layout/app-permissions-auth/app-permissions-auth-create-component']]
]);                
