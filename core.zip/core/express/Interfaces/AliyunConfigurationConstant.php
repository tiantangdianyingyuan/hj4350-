<?php

namespace app\core\express\Interfaces;

interface AliyunConfigurationConstant
{

}
