<?php

namespace app\core\express\Interfaces;

interface KdniaoConfigurationConstant
{
}
