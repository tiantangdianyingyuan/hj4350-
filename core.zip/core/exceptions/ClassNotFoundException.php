<?php
/**
 * Created by IntelliJ IDEA.
 * User: luwei
 * Date: 2019/3/5
 * Time: 14:14
 */

namespace app\core\exceptions;


class ClassNotFoundException extends \Exception
{

}
